#!/bin/bash

# Check if the script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit
fi

# List available drives
lsblk

# Ask the user for the hostname
read -p "Enter the hostname for the system: " HOSTNAME

# Ask the user for the root password
read -sp "Enter the root password: " ROOT_PASSWORD
echo

# Ask the user for the new user's name
read -p "Enter the name of the new user: " NEW_USER

# Ask the user for the new user's password
read -sp "Enter the password for the new user: " USER_PASSWORD
echo

# Ask the user to select the drive
read -p "Enter the drive you want to use (e.g., /dev/sda): " DRIVE

# Create a new GPT partition table and a single ext4 partition with parted
parted --script $DRIVE \
  mklabel gpt \
  mkpart primary fat32 1MiB 1GiB \
  set 1 esp on \
  mkpart primary ext4 1GiB 100%

# Format the partition to ext4
mkfs.fat -F32 ${DRIVE}1
mkfs.ext4 ${DRIVE}2

# Mount the partition
mount ${DRIVE}2 /mnt

# Create any directories you need
mkdir -p /mnt/boot

# (Optional) If you want to mount a boot partition separately in the future:
mount ${DRIVE}1 /mnt/boot

echo "Partitioning and formatting complete!"

pacstrap -K /mnt - < packages

genfstab -U /mnt > /mnt/etc/fstab

# Remove zram entries from fstab
arch-chroot /mnt sed -i '/^\/dev\/zram/d' /etc/fstab

# Define the mount point
MOUNT_POINT="/mnt"

# Chroot into the new installation and run the commands
arch-chroot $MOUNT_POINT /bin/bash <<EOF
ln -sf /usr/share/zoneinfo/Europe/Tirane /etc/localtime
hwclock --systohc

echo "en_US.UTF-8 UTF-8" >> /etc/locale.gen
locale-gen

echo "LANG=en_US.UTF-8" >> /etc/locale.conf

echo "$HOSTNAME" > /etc/hostname

# Set up /etc/hosts
cat <<EOL > /etc/hosts
127.0.0.1               localhost
::1                     localhost
127.0.1.1               $HOSTNAME.localdomain $HOSTNAME
EOL

mkinitcpio -P

# Set root password
echo "root:$ROOT_PASSWORD" | chpasswd

# Create a new user
useradd -m $NEW_USER
echo "$NEW_USER:$USER_PASSWORD" | chpasswd

# Uncomment wheel group in sudoers
sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers
echo "$NEW_USER ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
rm /etc/sudoers.d/*

# Install and configure GRUB for BIOS (MBR)
grub-install --target=x86_64-efi --efi-directory=/boot --bootloader-id=$HOSTNAME
grub-mkconfig -o /boot/grub/grub.cfg

cp -r dotfiles /home/$NEW_USER/
cd /home/$NEW_USER/dotfiles/
stow .

EOF


echo "Installation successfull. Please verify /etc/fstab!"
