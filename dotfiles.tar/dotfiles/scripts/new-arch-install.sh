#!/bin/bash

# Check if the script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit
fi

# List available drives
lsblk

# Ask the user to select the drive
read -p "Enter the drive you want to use (e.g., /dev/sda): " DRIVE

# Ask the user for the hostname
read -p "Enter the hostname for the system: " HOSTNAME

# Ask the user for the root password
read -sp "Enter the root password: " ROOT_PASSWORD
echo

# Ask the user for the new user's name
read -p "Enter the name of the new user: " NEW_USER

# Ask the user for the new user's password
read -sp "Enter the password for the new user: " USER_PASSWORD
echo

# Partition and format the selected drive
echo -e "g\nn\n1\n\n+1G\nt\n1\nn\n2\n\n\nw" | fdisk $DRIVE
mkfs.fat -F32 ${DRIVE}1 && mkfs.btrfs -f ${DRIVE}2

mount ${DRIVE}2 /mnt
btrfs subvolume create /mnt/@
btrfs subvolume create /mnt/@home
btrfs subvolume create /mnt/@var
btrfs subvolume create /mnt/@snapshots
btrfs subvolume create /mnt/@log
umount /mnt
mount -o noatime,compress=zstd,subvol=@ ${DRIVE}2 /mnt
mkdir -p /mnt/{boot,home,var,snapshots,log}
mount -o noatime,compress=zstd,subvol=@home ${DRIVE}2 /mnt/home
mount -o noatime,compress=zstd,subvol=@var ${DRIVE}2 /mnt/var
mount -o noatime,compress=zstd,subvol=@snapshots ${DRIVE}2 /mnt/snapshots
mount -o noatime,compress=zstd,subvol=@log ${DRIVE}2 /mnt/log
mkdir /mnt/boot
mount ${DRIVE}1 /mnt/boot

pacstrap -K /mnt aria2 asus-fan-control base base-devel bash-completion brightnessctl btop chaotic-keyring chaotic-mirrorlist cliphist cmatrix cups duf dunst efibootmgr eza fastfetch fish git google-chrome gnome grim grub hyprland imagemagick intel-gpu-tools intel-media-driver intel-ucode jq kitty less libheif libva-intel-driver libva-mesa-driver libva-utils linux linux-firmware mkinitcpio nano networkmanager network-manager-applet noto-fonts nvtop otf-font-awesome pacman-contrib pipewire pipewire-alsa pipewire-pulse polkit-gnome powertop slurp starship stremio supergfxctl sway-audio-idle-inhibit swaybg swaylock swayidle thermald unzip vlc vulkan-intel waybar wget wireplumber wlogout xdg-user-dirs xdg-utils yay yazi zoxide

#aria2 asus-fan-control autotiling base base-devel bash-completion blueberry brightnessctl btop chaotic-keyring chaotic-mirrorlist cmatrix cpupower cups dex duf dunst efibootmgr eza fastfetch feh ffmpeg fish gestures git google-chrome grub gstreamer gstreamer-vaapi i3 imagemagick intel-gpu-tools intel-media-driver intel-ucode jq kitty less libheif libva-intel-driver libva-mesa-driver libva-utils linux linux-firmware mousepad nano networkmanager network-manager-applet noto-fonts nvtop otf-font-awesome pacman-contrib pipewire pipewire-alsa pipewire-pulse picom polkit-gnome powertop ristretto sddm starship stremio supergfxctl thermald thunar thunar-archive-plugin thunar-media-tags-plugin thunar-volman tumbler udisks2-btrfs unzip vlc vulkan-intel wget wireplumber wmctrl x86_energy_perf_policy xarchiver xdg-user-dirs xdg-utils xdotool xfce4-appfinder xorg yay yazi zoxide

genfstab -U /mnt > /mnt/etc/fstab

# Remove zram entries from fstab
arch-chroot /mnt sed -i '/^\/dev\/zram/d' /etc/fstab

# Define the mount point
MOUNT_POINT="/mnt"

# Chroot into the new installation and run the commands
arch-chroot $MOUNT_POINT /bin/bash <<EOF
ln -sf /usr/share/zoneinfo/Europe/Tirane /etc/localtime
hwclock --systohc

echo "en_US.UTF-8 UTF-8" >> /etc/locale.gen
locale-gen

echo "LANG=en_US.UTF-8" >> /etc/locale.conf

echo "$HOSTNAME" > /etc/hostname

# Set up /etc/hosts
cat <<EOL > /etc/hosts
127.0.0.1               localhost
::1                     localhost
127.0.1.1               $HOSTNAME.localdomain $HOSTNAME
EOL

mkinitcpio -P

# Set root password
echo "root:$ROOT_PASSWORD" | chpasswd

# Create a new user
useradd -m $NEW_USER
echo "$NEW_USER:$USER_PASSWORD" | chpasswd

# Uncomment wheel group in sudoers
sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers
echo "joao ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers

# Install and configure GRUB
grub-install --target=x86_64-efi --efi-directory=/boot --bootloader-id=$HOSTNAME
grub-mkconfig -o /boot/grub/grub.cfg

# Create home directory
rm -rf joao
cd /home/
git clone https://github.com/joaomfds/dotfiles
tar xf dotfiles/joao.tar
rm -rf dotfiles

# Enable system services
systemctl enable afc bluetooth cups gdm NetworkManager supergfxd thermald udisks2 upower
#systemctl enable afc bluetooth cpupower cups NetworkManager sddm supergrxd thermald udisks2 upower
cd /home/joao/scripts
./install-battery-protection.sh
./install-chaotic_aur.sh
./install-powertop_service.sh
EOF


echo "Installation successfull. Please verify /etc/fstab!"
