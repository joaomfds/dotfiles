if status is-interactive
    # Commands to run in interactive sessions can go here
end

set -gx PATH /bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
set -gx LANG en_US.UTF-8
set -gx LC_ALL en_US.UTF-8
set -gx GTK_THEME Adwaita:dark
set -gx QT_QPA_PLATFORMTHEME qt6ct
set -gx QT_QPA_PLATFORM wayland

export EDITOR="nano"
export VISUAL="nano"
export PAGER="bat"
export TERM="foot"
export TERMINAL="foot -e"

set fish_greeting
starship init fish | source
zoxide init --cmd cd fish | source

## Useful aliases
# Replace ls with eza
alias ls='eza --color=always --group-directories-first --icons'
alias la='eza -a --color=always --group-directories-first --icons'
alias ll='eza -l --color=always --group-directories-first --icons'
alias lt='eza -aT --color=always --group-directories-first --icons'
alias l='eza -lah --color=always --group-directories-first --icons'
alias l.="eza -a | grep -e '^\.'"
alias mkdir='mkdir -p'
alias ps='ps auxf'
alias lf="yazi"
alias vi="vim"

## Environment setup
# Apply .profile: use this to put fish compatible .profile stuff in
if test -f ~/.fish_profile
  source ~/.fish_profile
end

# Add ~/.local/bin to PATH
if test -d ~/.local/bin
    if not contains -- ~/.local/bin $PATH
        set -p PATH ~/.local/bin
    end
end

# Add depot_tools to PATH
if test -d ~/Applications/depot_tools
    if not contains -- ~/Applications/depot_tools $PATH
        set -p PATH ~/Applications/depot_tools
    end
end

## Functions
# Functions needed for !! and !$ https://github.com/oh-my-fish/plugin-bang-bang
function __history_previous_command
  switch (commandline -t)
  case "!"
    commandline -t $history[1]; commandline -f repaint
  case "*"
    commandline -i !
  end
end

function __history_previous_command_arguments
  switch (commandline -t)
  case "!"
    commandline -t ""
    commandline -f history-token-search-backward
  case "*"
    commandline -i '$'
  end
end

if [ "$fish_key_bindings" = fish_vi_key_bindings ];
  bind -Minsert ! __history_previous_command
  bind -Minsert '$' __history_previous_command_arguments
else
  bind ! __history_previous_command
  bind '$' __history_previous_command_arguments
end

# Changing directories with yazi

function yy
	set tmp (mktemp -t "yazi-cwd.XXXXXX")
	yazi $argv --cwd-file="$tmp"
	if set cwd (cat -- "$tmp"); and [ -n "$cwd" ]; and [ "$cwd" != "$PWD" ]
		cd -- "$cwd"
	end
	rm -f -- "$tmp"
end

#if test -z "$WAYLAND_DISPLAY" && test "$XDG_VTNR" -eq 1
#    exec dbus-run-session sway
#end

