#!/bin/bash

# Path to temperature file (adjust this if necessary)
TEMP_FILE="/sys/class/thermal/thermal_zone0/temp"
# Fan control paths
FAN_CONTROL_PATH="/sys/devices/platform/asus-nb-wmi/hwmon/hwmon5/pwm1_enable"
# Temperature threshold (in Celsius)
TEMP_THRESHOLD=60

# Function to get current temperature
get_temp() {
    # Read temperature from the system file, divide by 1000 to convert to Celsius
    temp=$(cat $TEMP_FILE)
    echo $((temp / 1000))
}

# Function to control fan speed
control_fan() {
    echo 0 > $FAN_CONTROL_PATH
    sleep 1
    echo 2 > $FAN_CONTROL_PATH
    echo "Fan speed adjusted due to high temperature!"
}

# Infinite loop to monitor temperature
while true; do
    # Get the current temperature
    current_temp=$(get_temp)
    
    # If temperature is equal or higher than the threshold
    if [ "$current_temp" -ge "$TEMP_THRESHOLD" ]; then
        control_fan
    fi
    
    # Check every 10 seconds (you can adjust this interval)
    sleep 10
done
