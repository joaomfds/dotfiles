echo 0 > /sys/devices/platform/asus-nb-wmi/hwmon/hwmon5/pwm1_enable
sleep 1
echo 2 > /sys/devices/platform/asus-nb-wmi/hwmon/hwmon5/pwm1_enable

